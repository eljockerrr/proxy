# Socks VPN – SOCKS5 → full-device VPN (hev-socks5-tunnel)

## Build
1. Android Studio (Ladybug+), SDK Platform 35, NDK 27.1.12297006 (SDK Manager → SDK Tools).
2. Fetch the native engine:
   git init
   git submodule add https://github.com/heiher/hev-socks5-tunnel app/src/main/jni/hev-socks5-tunnel
   git submodule update --init --recursive
3. Open the folder in Android Studio, sync, then Build ▸ Build APK(s)
   (CLI: run `gradle wrapper` once, then `./gradlew assembleRelease`).
   Sign the release APK (Build ▸ Generate Signed App Bundle/APK) or use assembleDebug to test.
4. Hardening: Settings ▸ Network ▸ VPN ▸ ⚙ on this app → enable "Always-on VPN" and
   "Block connections without VPN". That is the only thing that also covers process death.

## Check against upstream
hev-socks5-tunnel's JNI class/package (PKGNAME/CLSNAME) and YAML keys live in its README / src/hev-jni.c.
If your checked-out version differs, adjust Application.mk, hev/htproxy/TProxyService.java and TunConfig.kt.
