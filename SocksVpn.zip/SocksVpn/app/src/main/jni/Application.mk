APP_OPTIM := release
APP_PLATFORM := android-26
NDK_TOOLCHAIN_VERSION := clang
APP_CFLAGS := -O3 -DPKGNAME=hev/htproxy -DCLSNAME=TProxyService
