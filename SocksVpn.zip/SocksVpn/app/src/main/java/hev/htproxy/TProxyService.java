package hev.htproxy;

/** JNI bridge. Package/class name must match PKGNAME/CLSNAME in Application.mk. */
public final class TProxyService {
    static { System.loadLibrary("hev-socks5-tunnel"); }
    private TProxyService() {}
    public static native void TProxyStartService(String configPath, int tunFd);
    public static native void TProxyStopService();
    /** {txPackets, txBytes, rxPackets, rxBytes} */
    public static native long[] TProxyGetStats();
}
