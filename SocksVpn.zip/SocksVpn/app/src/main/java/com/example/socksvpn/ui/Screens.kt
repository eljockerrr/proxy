package com.example.socksvpn.ui

import android.content.Intent
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.socksvpn.data.ProxyProfile
import com.example.socksvpn.vpn.VpnController
import com.example.socksvpn.vpn.VpnState

@Composable
fun Root(vm: MainViewModel, onConnect: (Long) -> Unit, onDisconnect: () -> Unit) {
    var editing by remember { mutableStateOf<ProxyProfile?>(null) }
    var showEdit by remember { mutableStateOf(false) }
    BackHandler(showEdit) { showEdit = false }
    if (showEdit) EditScreen(
        initial = editing,
        onSave = { vm.save(it); showEdit = false },
        onDelete = { vm.delete(it); showEdit = false },
        onBack = { showEdit = false })
    else MainScreen(vm, onConnect, onDisconnect,
        onAdd = { editing = null; showEdit = true },
        onEdit = { editing = it; showEdit = true })
}

private fun bytes(n: Long): String = when {
    n < 1024 -> "$n B"
    n < 1024 * 1024 -> "%.1f KB".format(n / 1024.0)
    n < 1024L * 1024 * 1024 -> "%.1f MB".format(n / 1048576.0)
    else -> "%.2f GB".format(n / 1073741824.0)
}

@Composable
fun MainScreen(vm: MainViewModel, onConnect: (Long) -> Unit, onDisconnect: () -> Unit,
               onAdd: () -> Unit, onEdit: (ProxyProfile) -> Unit) {
    val ctx = LocalContext.current
    val profiles by vm.profiles.collectAsStateWithLifecycle()
    val activeId by vm.activeId.collectAsStateWithLifecycle()
    val ks by vm.killSwitch.collectAsStateWithLifecycle()
    val lat by vm.latency.collectAsStateWithLifecycle()
    val state by VpnController.state.collectAsStateWithLifecycle()
    val tr by VpnController.traffic.collectAsStateWithLifecycle()
    var askKs by remember { mutableStateOf(false) }
    val on = state !is VpnState.Disconnected && state !is VpnState.Error

    if (askKs) AlertDialog(
        onDismissRequest = { askKs = false },
        title = { Text("Enable Kill Switch?") },
        text = { Text("If the proxy drops or fails, ALL internet traffic is blocked instead of falling back to Wi-Fi/cellular. " +
                "Traffic resumes when the proxy is reachable again, or you disconnect manually.\n\n" +
                "For protection even if the app is force-stopped, also enable Android's \"Always-on VPN\" and " +
                "\"Block connections without VPN\" for this app in system VPN settings.") },
        confirmButton = { TextButton(onClick = { vm.setKillSwitch(true); askKs = false }) { Text("Enable") } },
        dismissButton = { TextButton(onClick = { askKs = false }) { Text("Cancel") } })

    Scaffold(floatingActionButton = { FloatingActionButton(onClick = onAdd) { Text("+") } }) { pad ->
        LazyColumn(Modifier.padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(when (val s = state) {
                                    is VpnState.Connected -> "Connected · ${s.profile}"
                                    is VpnState.Connecting -> "Connecting…"
                                    is VpnState.Blocked -> "BLOCKED (kill switch)"
                                    is VpnState.Error -> "Error: ${s.message}"
                                    else -> "Disconnected"
                                }, style = MaterialTheme.typography.titleMedium)
                                (state as? VpnState.Connected)?.let { Text("Tunnel IP ${it.tunIp} → proxy ${it.proxy}") }
                                (state as? VpnState.Blocked)?.let { Text("${it.reason} – waiting for proxy…") }
                            }
                            Switch(checked = on, enabled = profiles.isNotEmpty() && activeId >= 0,
                                onCheckedChange = { if (it) onConnect(activeId) else onDisconnect() })
                        }
                        if (state is VpnState.Connected)
                            Text("↑ ${bytes(tr.tx)} (${bytes(tr.txRate)}/s)   ↓ ${bytes(tr.rx)} (${bytes(tr.rxRate)}/s)")
                    }
                }
            }
            item {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Kill switch", style = MaterialTheme.typography.titleSmall)
                        Text("Block all traffic if the proxy drops", style = MaterialTheme.typography.bodySmall)
                    }
                    Switch(checked = ks, onCheckedChange = { if (it) askKs = true else vm.setKillSwitch(false) })
                }
                TextButton(onClick = { ctx.startActivity(Intent(Settings.ACTION_VPN_SETTINGS)) }) {
                    Text("System Always-on / lockdown settings")
                }
            }
            items(profiles, key = { it.id }) { p ->
                Card(Modifier.fillMaxWidth().clickable { vm.select(p.id) }) {
                    Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = p.id == activeId, onClick = { vm.select(p.id) })
                        Column(Modifier.weight(1f)) {
                            Text(p.name, style = MaterialTheme.typography.titleSmall)
                            Text("${p.host}:${p.port}${if (p.udp) " · UDP" else ""}", style = MaterialTheme.typography.bodySmall)
                            lat[p.id]?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
                        }
                        TextButton(onClick = { vm.test(p) }) { Text("Test") }
                        TextButton(onClick = { onEdit(p) }) { Text("Edit") }
                    }
                }
            }
        }
    }
}

@Composable
fun EditScreen(initial: ProxyProfile?, onSave: (ProxyProfile) -> Unit,
               onDelete: (ProxyProfile) -> Unit, onBack: () -> Unit) {
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var host by remember { mutableStateOf(initial?.host ?: "") }
    var port by remember { mutableStateOf(initial?.port?.toString() ?: "1080") }
    var user by remember { mutableStateOf(initial?.username ?: "") }
    var pass by remember { mutableStateOf(initial?.password ?: "") }
    var udp by remember { mutableStateOf(initial?.udp ?: false) }

    val portN = port.toIntOrNull()
    val eName = name.isBlank()
    val eHost = host.isBlank() || host.any { it.isWhitespace() }
    val ePort = portN == null || portN !in 1..65535
    val eAuth = user.toByteArray().size > 255 || pass.toByteArray().size > 255 || (user.isEmpty() && pass.isNotEmpty())
    val valid = !(eName || eHost || ePort || eAuth)

    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(if (initial == null) "Add proxy" else "Edit proxy", style = MaterialTheme.typography.titleLarge)
        OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth(), label = { Text("Profile name") },
            isError = eName, supportingText = { if (eName) Text("Required") })
        OutlinedTextField(host, { host = it }, Modifier.fillMaxWidth(), label = { Text("Server IP / host") },
            isError = eHost, singleLine = true,
            supportingText = { Text(if (eHost) "Required, no spaces" else "Use an IPv4 address to avoid a DNS lookup of the proxy name") })
        OutlinedTextField(port, { port = it.filter(Char::isDigit) }, Modifier.fillMaxWidth(), label = { Text("Port") },
            isError = ePort, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            supportingText = { if (ePort) Text("1–65535") })
        OutlinedTextField(user, { user = it }, Modifier.fillMaxWidth(), label = { Text("Username (optional)") }, singleLine = true)
        OutlinedTextField(pass, { pass = it }, Modifier.fillMaxWidth(), label = { Text("Password (optional)") },
            singleLine = true, visualTransformation = PasswordVisualTransformation(),
            isError = eAuth, supportingText = { if (eAuth) Text("Max 255 bytes; password needs a username") })
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("UDP support (SOCKS5 UDP ASSOCIATE)", Modifier.weight(1f))
            Switch(udp, { udp = it })
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(enabled = valid, onClick = {
                onSave(ProxyProfile(initial?.id ?: 0, name.trim(), host.trim(), portN!!,
                    user.ifEmpty { null }, pass.ifEmpty { null }, udp))
            }) { Text("Save") }
            OutlinedButton(onClick = onBack) { Text("Cancel") }
            if (initial != null) TextButton(onClick = { onDelete(initial) }) { Text("Delete") }
        }
    }
}
