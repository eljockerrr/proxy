package com.example.socksvpn.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "proxy_profiles")
data class ProxyProfile(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,              // full UTF-8 (Arabic etc.) - SQLite stores TEXT as UTF-8
    val host: String,
    val port: Int,
    val username: String? = null,
    val password: String? = null,
    val udp: Boolean = false
)

@Dao
interface ProxyDao {
    @Query("SELECT * FROM proxy_profiles ORDER BY name COLLATE NOCASE")
    fun observeAll(): Flow<List<ProxyProfile>>

    @Query("SELECT * FROM proxy_profiles WHERE id = :id")
    suspend fun get(id: Long): ProxyProfile?

    @Upsert suspend fun upsert(p: ProxyProfile): Long
    @Delete suspend fun delete(p: ProxyProfile)
}
