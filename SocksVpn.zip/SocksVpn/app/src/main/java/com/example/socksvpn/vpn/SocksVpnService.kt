package com.example.socksvpn.vpn

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.example.socksvpn.App
import com.example.socksvpn.MainActivity
import com.example.socksvpn.data.ProxyProfile
import hev.htproxy.TProxyService
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.io.File
import java.net.Inet4Address
import java.net.InetAddress

class SocksVpnService : VpnService() {

    companion object {
        const val ACTION_CONNECT = "com.example.socksvpn.CONNECT"
        const val ACTION_DISCONNECT = "com.example.socksvpn.DISCONNECT"
        const val EXTRA_ID = "id"
        private const val CHANNEL = "vpn"
        private const val NID = 1
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val lock = Mutex()              // serialises connect / switch / teardown / monitor
    private lateinit var app: App

    private var tun: ParcelFileDescriptor? = null   // held open across proxy failures = kill switch
    private var profile: ProxyProfile? = null
    private var proxyIp: String? = null
    private var engineRunning = false
    private var monitorJob: Job? = null
    private var statsJob: Job? = null

    override fun onCreate() {
        super.onCreate()
        app = application as App
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "VPN status", NotificationManager.IMPORTANCE_LOW))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Must go foreground immediately, for every start path.
        val n = notif("Starting…")
        if (Build.VERSION.SDK_INT >= 34)
            ServiceCompat.startForeground(this, NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SYSTEM_EXEMPTED)
        else startForeground(NID, n)

        when (intent?.action) {
            ACTION_DISCONNECT -> scope.launch { lock.withLock { teardown(null) } }
            ACTION_CONNECT -> scope.launch { connect(intent.getLongExtra(EXTRA_ID, -1)) }
            // Always-on VPN start ("android.net.VpnService") or sticky restart after process death
            else -> scope.launch { connect(app.prefs.activeId.first()) }
        }
        return START_STICKY
    }

    // ---------------------------------------------------------------- connect / switch

    private suspend fun connect(id: Long): Unit = lock.withLock {
        val p = app.repo.get(id) ?: run { teardown("No proxy profile selected"); return@withLock }
        app.prefs.setActive(id)
        VpnController.state.value = VpnState.Connecting
        monitorJob?.cancel()
        stopEngine()                         // TUN (if up) stays open => packets black-holed during switch
        profile = p; proxyIp = null

        if (!ensureTun()) { teardown("Could not establish VPN (permission revoked?)"); return@withLock }

        val ip = resolve4(p.host)
        if (ip == null) { failOrBlock("Cannot resolve ${p.host}"); return@withLock }
        proxyIp = ip

        val probe = ProxyProbe.handshake(p, ip, protect = { protect(it) })
        if (probe.isFailure) { failOrBlock(probe.exceptionOrNull()?.message ?: "Handshake failed"); return@withLock }

        startEngine(p, ip)
        startMonitor()
    }

    private fun ensureTun(): Boolean {
        if (tun != null) return true
        val b = Builder()
            .setSession("Socks VPN")
            .setMtu(TunConfig.MTU)
            .addAddress(TunConfig.TUN_V4, 32)
            .addRoute("0.0.0.0", 0)                 // all IPv4 -> TUN
            .addAddress("fd00:1:fd00:1::1", 128)    // IPv6: claim ::/0 so it can't bypass,
            .addRoute("::", 0)                      // engine has no IPv6 => every v6 packet is dropped
            .addDnsServer(TunConfig.DNS_V4)         // all DNS -> mapdns -> resolved proxy-side
            .setConfigureIntent(PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE))
        // Native engine sockets can't be protect()ed from Java, so exclude our own process from
        // the VPN instead: engine->proxy traffic goes out the physical network, no routing loop.
        runCatching { b.addDisallowedApplication(packageName) }
        // NOTE: allowBypass() is deliberately NOT called -> apps cannot bypass the tunnel.
        if (Build.VERSION.SDK_INT >= 29) b.setMetered(false)
        tun = b.establish()
        return tun != null
    }

    private suspend fun resolve4(host: String): String? = withContext(Dispatchers.IO) {
        runCatching { InetAddress.getAllByName(host).first { it is Inet4Address }.hostAddress }.getOrNull()
    }

    // ---------------------------------------------------------------- engine

    private fun startEngine(p: ProxyProfile, ip: String) {
        val cfg = File(filesDir, "tproxy.yml")
        cfg.writeText(TunConfig.yaml(p, ip), Charsets.UTF_8)
        TProxyService.TProxyStartService(cfg.absolutePath, tun!!.fd)
        engineRunning = true
        VpnController.state.value = VpnState.Connected(p.name, TunConfig.TUN_V4, "$ip:${p.port}")
        update("Connected: ${p.name}")
        startStats()
    }

    private suspend fun stopEngine() {
        statsJob?.cancel(); statsJob = null
        if (!engineRunning) return
        engineRunning = false
        withContext(Dispatchers.IO) { runCatching { TProxyService.TProxyStopService() } }
    }

    private fun startStats() {
        statsJob?.cancel()
        statsJob = scope.launch {
            var lastTx = 0L; var lastRx = 0L
            while (isActive) {
                delay(1000)
                val s: LongArray? = runCatching { TProxyService.TProxyGetStats() }.getOrNull()
                if (s != null && s.size >= 4) {
                    val tx = s[1]; val rx = s[3]
                    VpnController.traffic.value = Traffic(tx, rx, maxOf(0, tx - lastTx), maxOf(0, rx - lastRx))
                    lastTx = tx; lastRx = rx
                }
            }
        }
    }

    // ---------------------------------------------------------------- kill switch / health

    private fun startMonitor() {
        monitorJob?.cancel()
        monitorJob = scope.launch {
            var fails = 0
            while (isActive) {
                delay(if (engineRunning) 5_000 else 3_000)
                val p = profile ?: break
                val ip = proxyIp ?: resolve4(p.host)?.also { proxyIp = it }
                val ok = ip != null && ProxyProbe.handshake(p, ip, protect = { protect(it) }, timeoutMs = 4000).isSuccess
                lock.withLock {
                    if (ok) {
                        fails = 0
                        if (!engineRunning && tun != null && profile?.id == p.id) startEngine(p, ip!!)   // resume
                    } else if (++fails >= 2 && engineRunning) {
                        failOrBlock("Proxy connection lost")
                    }
                }
            }
        }
    }

    /** Kill switch ON: keep TUN open, stop engine => nothing reads the TUN => all traffic dropped.
     *  Kill switch OFF: tear the VPN down (device falls back to normal network). */
    private suspend fun failOrBlock(reason: String) {
        val ks = app.prefs.killSwitch.first()
        if (ks && tun != null) {
            stopEngine()
            VpnController.state.value = VpnState.Blocked(reason)
            update("BLOCKED – $reason")
            if (monitorJob?.isActive != true) startMonitor()
        } else {
            scope.launch { lock.withLock { teardown(reason) } }   // separate coroutine: teardown cancels the monitor
        }
    }

    // ---------------------------------------------------------------- teardown

    private suspend fun teardown(error: String?) {
        monitorJob?.cancel()
        stopEngine()
        tun?.close(); tun = null
        File(filesDir, "tproxy.yml").delete()       // contains proxy credentials
        profile = null; proxyIp = null
        VpnController.traffic.value = Traffic()
        VpnController.state.value = if (error != null) VpnState.Error(error) else VpnState.Disconnected
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onRevoke() {                       // user revoked permission / another VPN took over
        scope.launch { lock.withLock { teardown("VPN revoked by system") } }
    }

    override fun onDestroy() {
        if (engineRunning) runCatching { TProxyService.TProxyStopService() }
        tun?.close(); tun = null
        scope.cancel()
        super.onDestroy()
    }

    // ---------------------------------------------------------------- notification

    private fun notif(text: String): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getForegroundService(
            this, 1, Intent(this, SocksVpnService::class.java).setAction(ACTION_DISCONNECT), PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentTitle("Socks VPN").setContentText(text)
            .setOngoing(true).setContentIntent(open)
            .addAction(0, "Disconnect", stop).build()
    }

    private fun update(text: String) =
        getSystemService(NotificationManager::class.java).notify(NID, notif(text))
}
