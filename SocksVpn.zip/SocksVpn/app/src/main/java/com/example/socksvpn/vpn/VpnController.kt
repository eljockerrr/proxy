package com.example.socksvpn.vpn

import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import kotlinx.coroutines.flow.MutableStateFlow

sealed interface VpnState {
    data object Disconnected : VpnState
    data object Connecting : VpnState
    data class Connected(val profile: String, val tunIp: String, val proxy: String) : VpnState
    /** Kill switch engaged: TUN is held open, engine stopped, every packet is dropped. */
    data class Blocked(val reason: String) : VpnState
    data class Error(val message: String) : VpnState
}

data class Traffic(val tx: Long = 0, val rx: Long = 0, val txRate: Long = 0, val rxRate: Long = 0)

object VpnController {
    val state = MutableStateFlow<VpnState>(VpnState.Disconnected)
    val traffic = MutableStateFlow(Traffic())

    fun connect(ctx: Context, profileId: Long) = send(ctx, SocksVpnService.ACTION_CONNECT, profileId)
    fun disconnect(ctx: Context) = send(ctx, SocksVpnService.ACTION_DISCONNECT, -1)

    private fun send(ctx: Context, action: String, id: Long) {
        ContextCompat.startForegroundService(
            ctx,
            Intent(ctx, SocksVpnService::class.java).setAction(action).putExtra(SocksVpnService.EXTRA_ID, id)
        )
    }
}
