package com.example.socksvpn

import android.Manifest
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.socksvpn.ui.Root
import com.example.socksvpn.vpn.VpnController

class MainActivity : ComponentActivity() {
    private var pendingId = -1L

    private val vpnPermission = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (it.resultCode == RESULT_OK && pendingId >= 0) VpnController.connect(this, pendingId)
    }
    private val notifPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) {}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        setContent {
            MaterialTheme(colorScheme = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()) {
                Surface {
                    Root(
                        vm = viewModel(),
                        onConnect = ::requestConnect,
                        onDisconnect = { VpnController.disconnect(this) }
                    )
                }
            }
        }
    }

    private fun requestConnect(id: Long) {
        val prep = VpnService.prepare(this)      // null => already authorised
        if (prep != null) { pendingId = id; vpnPermission.launch(prep) }
        else VpnController.connect(this, id)
    }
}
