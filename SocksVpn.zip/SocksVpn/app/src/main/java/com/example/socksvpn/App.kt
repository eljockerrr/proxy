package com.example.socksvpn

import android.app.Application
import com.example.socksvpn.data.AppDatabase
import com.example.socksvpn.data.Prefs
import com.example.socksvpn.data.ProxyRepository

class App : Application() {
    val db by lazy { AppDatabase.get(this) }
    val repo by lazy { ProxyRepository(db.proxyDao()) }
    val prefs by lazy { Prefs(this) }
}
