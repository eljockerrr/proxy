package com.example.socksvpn.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.socksvpn.App
import com.example.socksvpn.data.ProxyProfile
import com.example.socksvpn.vpn.ProxyProbe
import com.example.socksvpn.vpn.VpnController
import com.example.socksvpn.vpn.VpnState
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val a = app as App
    private val eager = SharingStarted.WhileSubscribed(5000)

    val profiles = a.repo.observeAll().stateIn(viewModelScope, eager, emptyList())
    val activeId = a.prefs.activeId.stateIn(viewModelScope, eager, -1L)
    val killSwitch = a.prefs.killSwitch.stateIn(viewModelScope, eager, true)
    val latency = MutableStateFlow<Map<Long, String>>(emptyMap())

    /** One-tap switch: if the tunnel is up, the service swaps the proxy on the SAME TUN (no leak window). */
    fun select(id: Long) = viewModelScope.launch {
        a.prefs.setActive(id)
        if (VpnController.state.value.let { it is VpnState.Connected || it is VpnState.Blocked || it is VpnState.Connecting })
            VpnController.connect(getApplication(), id)
    }

    fun setKillSwitch(on: Boolean) = viewModelScope.launch { a.prefs.setKillSwitch(on) }

    fun test(p: ProxyProfile) = viewModelScope.launch {
        latency.update { it + (p.id to "…") }
        val r = ProxyProbe.handshake(p)
        latency.update { it + (p.id to (r.getOrNull()?.let { ms -> "$ms ms" } ?: "failed")) }
    }

    fun save(p: ProxyProfile) = viewModelScope.launch {
        val id = a.repo.save(p)
        if (activeId.value < 0) a.prefs.setActive(if (p.id != 0L) p.id else id)
    }

    fun delete(p: ProxyProfile) = viewModelScope.launch { a.repo.delete(p) }
}
