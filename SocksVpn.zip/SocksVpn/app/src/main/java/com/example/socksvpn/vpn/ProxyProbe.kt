package com.example.socksvpn.vpn

import com.example.socksvpn.data.ProxyProfile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.DataInputStream
import java.net.InetSocketAddress
import java.net.Socket

/** SOCKS5 greeting (+ RFC1929 auth) check. Returns round-trip ms. */
object ProxyProbe {
    suspend fun handshake(
        p: ProxyProfile,
        host: String = p.host,
        protect: ((Socket) -> Unit)? = null,
        timeoutMs: Int = 5000
    ): Result<Long> = withContext(Dispatchers.IO) {
        runCatching {
            val t0 = System.nanoTime()
            Socket().use { s ->
                protect?.invoke(s)
                s.soTimeout = timeoutMs
                s.tcpNoDelay = true
                s.connect(InetSocketAddress(host, p.port), timeoutMs)
                val out = s.getOutputStream()
                val inp = DataInputStream(s.getInputStream())
                val user = p.username?.toByteArray(Charsets.UTF_8)
                val pass = (p.password ?: "").toByteArray(Charsets.UTF_8)
                val auth = user != null && user.isNotEmpty()

                out.write(if (auth) byteArrayOf(5, 2, 0, 2) else byteArrayOf(5, 1, 0)); out.flush()
                val r = ByteArray(2); inp.readFully(r)
                check(r[0].toInt() == 5) { "Not a SOCKS5 server" }
                when (r[1].toInt() and 0xFF) {
                    0 -> {}
                    2 -> {
                        check(auth) { "Proxy requires credentials" }
                        out.write(byteArrayOf(1, user!!.size.toByte()) + user + byteArrayOf(pass.size.toByte()) + pass)
                        out.flush()
                        val a = ByteArray(2); inp.readFully(a)
                        check(a[1].toInt() == 0) { "Authentication failed" }
                    }
                    else -> error("No acceptable auth method")
                }
                (System.nanoTime() - t0) / 1_000_000
            }
        }
    }
}
