package com.example.socksvpn.vpn

import com.example.socksvpn.data.ProxyProfile

object TunConfig {
    const val TUN_V4 = "198.18.0.1"
    const val DNS_V4 = "198.18.0.2"   // hev "mapdns": answers with fake IPs, then CONNECTs by DOMAIN via the proxy
    const val MTU = 8500

    private fun q(s: String) = "'" + s.replace("'", "''") + "'"

    /** No `tunnel.ipv6` key => hev drops all IPv6 packets. `udp` key only when enabled. */
    fun yaml(p: ProxyProfile, ip: String) = buildString {
        appendLine("tunnel:")
        appendLine("  mtu: $MTU")
        appendLine("  ipv4: $TUN_V4")
        appendLine("socks5:")
        appendLine("  port: ${p.port}")
        appendLine("  address: ${q(ip)}")
        if (p.udp) appendLine("  udp: 'udp'")
        if (!p.username.isNullOrEmpty()) {
            appendLine("  username: ${q(p.username)}")
            appendLine("  password: ${q(p.password ?: "")}")
        }
        appendLine("mapdns:")
        appendLine("  address: $DNS_V4")
        appendLine("  port: 53")
        appendLine("  network: 100.64.0.0")
        appendLine("  netmask: 255.192.0.0")
        appendLine("  cache-size: 10000")
        appendLine("misc:")
        appendLine("  task-stack-size: 81920")
        appendLine("  connect-timeout: 5000")
        appendLine("  read-write-timeout: 60000")
        appendLine("  log-file: stderr")
        appendLine("  log-level: warn")
    }
}
