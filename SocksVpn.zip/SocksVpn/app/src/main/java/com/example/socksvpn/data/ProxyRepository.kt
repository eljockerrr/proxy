package com.example.socksvpn.data

import kotlinx.coroutines.flow.Flow

class ProxyRepository(private val dao: ProxyDao) {
    fun observeAll(): Flow<List<ProxyProfile>> = dao.observeAll()
    suspend fun get(id: Long) = dao.get(id)
    suspend fun save(p: ProxyProfile) = dao.upsert(p)
    suspend fun delete(p: ProxyProfile) = dao.delete(p)
}
