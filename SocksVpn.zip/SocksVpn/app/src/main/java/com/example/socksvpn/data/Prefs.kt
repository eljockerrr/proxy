package com.example.socksvpn.data

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.store by preferencesDataStore(name = "settings")

class Prefs(private val ctx: Context) {
    val activeId: Flow<Long> = ctx.store.data.map { it[ACTIVE] ?: -1L }
    val killSwitch: Flow<Boolean> = ctx.store.data.map { it[KS] ?: true }

    suspend fun setActive(id: Long) { ctx.store.edit { it[ACTIVE] = id } }
    suspend fun setKillSwitch(on: Boolean) { ctx.store.edit { it[KS] = on } }

    private companion object {
        val ACTIVE = longPreferencesKey("active_id")
        val KS = booleanPreferencesKey("kill_switch")
    }
}
